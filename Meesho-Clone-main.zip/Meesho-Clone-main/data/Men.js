const Men = [
    {
        heading : "Top Wear",
        data : ["All Top Wear","Tshirts","Shirts"]
    },
    {
        heading : "Bottom Wear",
        data : ["Track Pants","Jeans","Trousers"]
    },
    {
        heading : "Men Accessories",
        data : ["All Men Accessories","Watches","Belts","Wallets","Jewellery","Sunglasses","Bags"]
    },
    {
        heading : "Men Footwear",
        data : ["Casual Shoes","Sports Shoes","Sandals","Formal Shoes"]
    },
    {
        heading : "Ethnic Wear",
        data : ["Men Kurtas","Ethnic Jackets"]
    },
    {
        heading : "Inner & Sleep Wear",
        data : ["All Inner & Sleep Wear","Vests"]
    },
]


export default Men