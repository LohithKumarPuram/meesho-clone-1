const JewelleryAccessories = [
    {
        heading : "Jewellery",
        data : ["Jewellery Set","Earrings","Mangalsutras","Studs","Bangles","Necklaces","Rings","Anklets"]
    },
    {
        heading : "Women Accessory",
        data : ["Bags","Watches","Hair Accessories","Sunglasses","Socks"]
    },
]

export default JewelleryAccessories